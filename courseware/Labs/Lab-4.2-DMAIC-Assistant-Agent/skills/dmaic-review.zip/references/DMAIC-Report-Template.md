# DMAIC Summary Template

Return exactly five rows.

| Stage | Required content |
|---|---|
| Define | Problem statement, scope, period and exclusions. |
| Measure | Inputs, totals, formulas, rates, units and row counts. |
| Analyse | Observed pattern, Pareto priority and separately labelled hypotheses. |
| Improve | Change made or proposed, plus evidence still required. |
| Control | Monitoring plan, stable-control limitation and blank reviewer decision. |

Finish with source list, unresolved questions and DRAFT FOR REVIEW.
