# DMAIC Calculation Rules

- Deviation rate = deviations / opportunities x 100%.
- Show numerator, denominator, result and period for each phase.
- Absolute percentage-point change = Baseline rate - Pilot rate when reporting a decrease.
- A relative change is not a percentage-point change. Do not substitute one for the other.
- Pareto category counts must sum to the recorded Baseline deviations.
- Pareto rank identifies where to investigate first; it does not establish root cause.
- A short pilot and concurrent changes do not prove causation or stable long-term control.
