# SPC Review Template

1. Data scope and subgroup definition
2. Subgroup statistics table: subgroup, phase, Xbar, R and unit
3. Baseline statistics and formulas
4. Frozen control limits and constants
5. Monitoring signals and triggered rules
6. Capability calculation, if specification limits were supplied
7. Interpretation caution
8. Missing evidence and unresolved questions
9. Reviewer decision: [blank]
10. DRAFT FOR REVIEW
