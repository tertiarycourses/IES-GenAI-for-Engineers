# Xbar-R Classroom Rules

- Subgroup Xbar = sum of subgroup observations / subgroup size.
- Subgroup R = maximum observation - minimum observation.
- Xbarbar = mean of Baseline subgroup means only.
- Rbar = mean of Baseline subgroup ranges only.
- Xbar UCL = Xbarbar + A2 x Rbar.
- Xbar LCL = Xbarbar - A2 x Rbar.
- R-chart UCL = D4 x Rbar. For subgroup size 4, the classroom R-chart LCL is zero.
- Estimated sigma = Rbar / d2.
- Cp = (USL - LSL) / (6 x sigma).
- Cpk = minimum of (USL - Xbarbar) / (3 x sigma) and (Xbarbar - LSL) / (3 x sigma).
- Use the supplied A2, D4 and d2 values. Never guess missing constants.
